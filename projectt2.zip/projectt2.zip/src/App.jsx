import React from "react";
import ProjectPage from "./components/ProjectPage";

function App() {
  // const [data, setData] = React.useState("")

  return (
    <>
      <ProjectPage />
      <blockquote cite="">
      
      </blockquote>=
    </>
  );
}

export default App;
