import { Fragment } from "react";
import React from "react";
import DaftarProject from "./DaftarProject";

const ProjectsPage = () => {
    return (
        <Fragment>
    
        <h1>hai</h1>
        <pre>{JSON.stringify(DaftarProject,null,"")}</pre>
    
    </Fragment>
    )
}

export default ProjectsPage